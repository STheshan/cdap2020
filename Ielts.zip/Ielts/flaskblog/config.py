class Config:

    SECRET_KEY = 'bcec6cfc03974b3fdb9e87253e03d977'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = 'True'
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'jeffery1996.jbw@gmail.com'
    MAIL_PASSWORD = 'gjtn sbko htud zsot'
    MAIL_DEBUG = True
